#define CDS_SENSOR_PIN 27
#define servoPin1 2           //iris L
#define servoPin2 0           //iris R
#define servoPin3 4           //slider 1
#define servoPin4 23          //slider 2
#define ledPin 16             //Neopixel Pin
#define numLeds 1             //Neopixel number
#define CDS_SENSOR_PIN 36     //CDS
#define relay_1 17            //DC Motor
#define I2C_SDA 12            //Contactfree_Temp_SDA
#define I2C_SCL 14            //Contactfree_Temp_SCL
#define Gas_Pin 39            //Gas Sensor   
#define Air_Pin 34            //Air Quality Sensor
#define Air_Led_Pin 5         //Air Quality IRled
#define Ultra1_Tri 32         //Ultra_Sonic1_Tri
#define Ultra1_Echo 33        //Ultra_Sonic1_Echo
#define Ultra2_Tri 13         //Ultra_Sonic2_Tri
#define Ultra2_Echo 35        //Ultra_Sonic2_Echo
