#include <ESP32_Servo.h>
#include <Adafruit_NeoPixel.h>
#include "definitions_pin.h"

//Servo
Servo servo1;
Servo servo2;
Servo servo3;
Servo servo4;

//NeoPixel
Adafruit_NeoPixel pixel(numLeds,ledPin,NEO_GRBW + NEO_KHZ800); 

void iris_open() {
    for(int posDegrees = 90; posDegrees <= 180; posDegrees++) {
        servo1.write(posDegrees); // 모터의 각도를 설정합니다.
        delay(5);
    }
    Serial.println("open - iris L");
    
    for(int posDegrees = 180; posDegrees >= 90; posDegrees--) {
        servo2.write(posDegrees); // 모터의 각도를 설정합니다.
        delay(5);
    }
    Serial.println("open - iris R");
}

void iris_close() {
    for(int posDegrees = 180; posDegrees >= 90; posDegrees--) {
        servo1.write(posDegrees); // 모터의 각도를 설정합니다.
        delay(5);
    }
    Serial.println("close - iris L");

     for(int posDegrees = 90; posDegrees <= 180; posDegrees++) {
        servo2.write(posDegrees); // 모터의 각도를 설정합니다.
        delay(5);
    }
    Serial.println("close - iris R");
}

void slider1_open(){
    for(int posDegrees = 90; posDegrees <= 120; posDegrees++) {
        servo3.write(posDegrees); // 모터의 각도를 설정합니다.
        delay(5);
    }
    Serial.println("open - slider1");
}

void slider1_close(){
  for(int posDegrees = 120; posDegrees >= 90; posDegrees--) {
        servo3.write(posDegrees); // 모터의 각도를 설정합니다.
        delay(5);
    }
    Serial.println("close - slider1");
}

void slider2_cig(){
    for(int posDegrees = 90; posDegrees <= 120; posDegrees++) {
        servo4.write(posDegrees); // 모터의 각도를 설정합니다.
        delay(5);
    }
    Serial.println("open - slider2");
}

void slider2_trash(){
  for(int posDegrees = 120; posDegrees >= 90; posDegrees--) {
        servo4.write(posDegrees); // 모터의 각도를 설정합니다.
        delay(5);
    }
    Serial.println("close - slider2");
}

void smash(){
  digitalWrite(relay_1,HIGH);
  delay(2500);
  digitalWrite(relay_1,LOW);
  delay(2500);
}

void neopixel_on(){
  //Neopixel init
  pixel.begin();
  pixel.show();
  pixel.setBrightness(255);
  
  //Neopixel white color
  pixel.setPixelColor(0,255,255,255,255);
  pixel.show();
}

void neopixel_off(){
  //Neopixel init
  pixel.begin();
  pixel.show();
  pixel.setBrightness(255);
  
  //Neopixel white color
  pixel.setPixelColor(0,0,0,0,0);
  pixel.show();
}

int cds(){
  Serial.println(analogRead(CDS_SENSOR_PIN));
  return analogRead(CDS_SENSOR_PIN);
}
