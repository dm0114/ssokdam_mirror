float dustValue = 0;
float voltage = 0;

float air_check(){
  digitalWrite(Air_Led_Pin,LOW);
  delayMicroseconds(280);
  dustValue = analogRead(Air_Pin);
  delayMicroseconds(40);
  digitalWrite(Air_Led_Pin,HIGH);
  delayMicroseconds(9680);
  voltage = dustValue * 5.0 / 1023.0;
  delay(100);
  return voltage;
}
