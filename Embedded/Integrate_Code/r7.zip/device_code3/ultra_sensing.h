long duration1, distance1;
long duration2, distance2;

int Trash_Check(){
  digitalWrite(Ultra1_Tri, LOW);
  delayMicroseconds(2);
  digitalWrite(Ultra1_Tri, HIGH);
  delayMicroseconds(10);
  digitalWrite(Ultra1_Tri, LOW);
  duration1 = pulseIn (Ultra1_Echo, HIGH);
  return distance1;
}

int Cig_Check(){
  digitalWrite(Ultra2_Tri, LOW);
  delayMicroseconds(2);
  digitalWrite(Ultra2_Tri, HIGH);
  delayMicroseconds(10);
  digitalWrite(Ultra2_Tri, LOW);
  duration2 = pulseIn (Ultra2_Echo, HIGH);
  return distance2;
}
