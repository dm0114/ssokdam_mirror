#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <Arduino_JSON.h>
#include "servocontrol.h"
#include "ContactFree_Temp_Test_header_v.h"
#include "airquality_header_v.h"
#include "gas_sensing.h"

//Your Domain name with URL path or IP address with path
const char* PostserverName = "https://ssokdam.com/api/embedded/send";
const char* ReturnserverName = "https://ssokdam.com/api/use";  
const char* GetserverName = "https://ssokdam.com/api/embedded/receive?embId=1";  //QR찍은 상태
int inputStatus= 0; //0은 투입 안된상태 1은 투입된상태
int ciga_check =0; // 0이면 담배아님 1이면 담배 맞음
char posting[128];
JSONVar userId;
String information;
String informationsArr[2];
void useCheckreturn(int ciga_check){ //0이면 담배아님 //1이면 담배임
        WiFiClientSecure client;
      HTTPClient http;
      client.setInsecure();

      
      http.begin(client, ReturnserverName); //use쪽으로 리턴한다.
  
      http.addHeader("Content-Type", "application/json");
      char input[] = "{\"embId\":1,\"userId\":\"test\",\"useCheck\": %c }";
      if(ciga_check ==0){
         sprintf(posting, input, 'N'); //담배 아님
      }else if(ciga_check == 1){
        
         sprintf(posting, input, 'Y'); //담배 임
      }
     
      int httpResponseCode = http.POST(posting);
      Serial.println(posting);
      Serial.print("HTTP Response code: ");
      Serial.println(httpResponseCode);
        
      // Free resources
      http.end();
}
void Post(){ //1시간마다 정보전달하는 함수 
        WiFiClientSecure client;
      HTTPClient http;
      client.setInsecure();
      long randnum1 = random(9999);
      long randnum2 = random(9999);
      long randnum3 = random(9999);
      long randnum4 = random(9999);

      http.begin(client, PostserverName);
  
      http.addHeader("Content-Type", "application/json");
      char input[] = "{\"embId\":1,\"userId\":\"test\",\"embFullTra\": %d ,\"embFullCig\":%d,\"embLat\":\"%d\",\"embLng\":\"%d\",\"embBat\":111,\"embCnt\":111,\"embSta\":\"Y\"}";
      sprintf(posting, input, randnum1, randnum2,randnum3,randnum4);
      int httpResponseCode = http.POST(posting);
      Serial.println(posting);
      
      Serial.print("HTTP Response code: ");
      Serial.println(httpResponseCode);
        
      // Free resources
      http.end();
}

String httpGETRequest(const char* GetserverName) {
  HTTPClient http;
  http.begin(GetserverName);
  int httpResponseCode = http.GET();
  String payload = "{}"; 
  if (httpResponseCode>0) {
    Serial.print("HTTP Response code: ");
    Serial.println(httpResponseCode);
    payload = http.getString();
  }
  else {
    Serial.print("Error code: ");
    Serial.println(httpResponseCode);
  }
  http.end();
  return payload;
}

void Get(){
  information = httpGETRequest(GetserverName);
  Serial.println(information);
  JSONVar myObject = JSON.parse(information);
  // JSON.typeof(jsonVar) can be used to get the type of the var
  if (JSON.typeof(myObject) == "undefined") {
    Serial.println("Parsing input failed!");
    return;
    }
  //Serial.print("JSON object = ");
  //Serial.println(myObject);
    
  // myObject.keys() can be used to get an array of all the keys in the object
  JSONVar keys = myObject.keys();
  for (int i = 0; i < keys.length(); i++) {
    JSONVar value = myObject[keys[i]];
    
    JSONVar Qrc = "Y"; //for check
    JSONVar UC = "userId";
    Serial.print(keys[i]);
    Serial.print(" = ");
    Serial.println(value);

    if( keys[i] == UC){ //사용자 아이디를 받아온다
     userId = value; //test
    }
    if (value == Qrc){ //y되는 순간 뚜껑이 열린다.
          inputStatus = 0; //넣었는지 안넣었는지 flag 초기화 
          ciga_check = 0;
          //서보모터 코드
          input_open(); //뚜껑 열림 - 지금은 각도가 180인식 안되서 무한루프임 일단 주석 처리
          Serial.println("뚜껑 열림");
          delay(1000);
          
        
          
         //여기서부터는 cds를 사용하여 무언가 들어왔는지를 확인하는 부분이다.
          for(int i=0;i<6;i++){ //6초간 입력 대기
            if(cds()==1){ //리턴 값이 1이면 cds에 물체가 통과 된것임
              inputStatus = 1; // 0은 입력 안받은 상태 1은 입력 받은 상태
              
              break; //바로 문닫으러 루프 탈출
            }else{//물체가 통과가 안됐으면 아직
              delay(1000);
            }        
          }
          input_close(); //입구 닫는다

          //여기서부터는 판별부이다 만약 inputStatus 가 0 즉 투입이 안됐으면 이부분은 넘어간다.
          if(inputStatus == 1){     
            
            if(temp_check() == 0){ //0이면 넘지 30도 넘지 않음.
              Serial.println("30도 넘지않음");
            }else if(gas_check() == 0){ //0이면 가스 감지 안됨
              Serial.println("가스감지 안됨");
            }else if(airquality_chek() == 0){ //0이면 깨끗함
              Serial.println("공기질 양호");
            }else{ //담배이다.
              //파쇄부
              shake(); //담배꽁초 판별되어 터는 작업 실시
              //담배인것을 확인했으니 이정보를 post해야함
              ciga_check = 1;
            }
          }   
          //기기에서의 메인 프로세스 종료 
          

        useCheckreturn(ciga_check);
            
    }
  }
  
}
